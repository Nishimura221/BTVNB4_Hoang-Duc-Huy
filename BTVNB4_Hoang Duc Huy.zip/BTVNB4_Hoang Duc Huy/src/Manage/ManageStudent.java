package Manage;
import Student.Student;
import java.util.Scanner;
import java.util.ArrayList;
public class ManageStudent {
   static ArrayList<Student>listStudent= new ArrayList<>();
    public void AddStudent(Student student){
        listStudent.add(student);
    }

    public void printMenu(){
        System.out.println("1.Add student");
        System.out.println("2.Edit student");
        System.out.println("3.Delete student");
        System.out.println("4.Search student by id");
        System.out.println("5.Sort student by gpa");
        System.out.println("6.Print list student");
        System.out.println("7.Exit");

    }
    public static void main(String[] args){
     ManageStudent stdMn = new ManageStudent();
     int choice;
     do {
         stdMn.printMenu();
         Scanner sc = new Scanner(System.in);
         System.out.println("Enter your choice: ");
          choice = Integer.parseInt(sc.nextLine());

         switch (choice) {
             case 1:
                 AddStudent1();
                 break;
             case 2:
                 EditStudent();
                 break;
             case 3:
                 DeleteStudent();
                 break;
             case 4:
                 SearchStudentByID();
                 break;
             case 5:
                 ShowAllListStudent();
                 break;
             case 6:
                 break;
             case 7:
                 System.out.println("Exit!!!");
                 break;
         }
     }while (choice!=7);

    }
        public static void AddStudent1(){
        Scanner sc= new Scanner(System.in);
            System.out.print("Enter the name: ");
        String name= sc.nextLine();
            System.out.print("Enter the Id: ");
        String Id= sc.nextLine();
            System.out.print("Enter the gpa: ");
        double gpa= sc.nextDouble();
        Student std= new Student(name,Id,gpa);
        ManageStudent stdMn= new ManageStudent();
        stdMn.AddStudent(std);
    }
    public static void EditStudent(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the ID of student to repair: ");
        String id= sc.nextLine();
        for(Student student:listStudent){
            if(student.getID()==id){
                System.out.println("Enter the new name: ");
                String name=sc.nextLine();
                System.out.println("Enter the new gpa number: ");
                double gpa= sc.nextDouble();
                student.setName(name);
                student.setGpa(gpa);
                System.out.println("Finish repair!!");

            }


        }

    }
    public static void DeleteStudent(){
        System.out.println("Enter the ID : ");
        Scanner sc=new Scanner(System.in);
        String id= sc.nextLine();
        for(Student student:listStudent){
            if(student.getID()==id){
                listStudent.remove(student);
                System.out.println("Delete complete!!!");
            }

        }
    }
    public static void SearchStudentByID(){
        System.out.println("Enter the ID: ");
        Scanner sc=new Scanner(System.in);
        String Id= sc.nextLine();
        for(Student student:listStudent){
            if(student.getID()==Id){
                System.out.println(student.toString());
            }

        }
    }
    public static void ShowAllListStudent(){
        for(int i=0;i<listStudent.size();i++){
            System.out.println(listStudent.get(i).toString());
        }


    }

}
